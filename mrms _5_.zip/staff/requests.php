<?php include("../php/staff_cookie.php")?>
<!DOCTYPE html>
  <html lang="en">
  <?php include("../php/head.php")?>
  <body>
    <?php include("../php/top_navigation.php")?>

    <section class="d-flex align-items-start justify-content-start flex-nowrap">
      <?php include("../php/left_navigation.php")?>
      <?php include("../php/global_requests.php")?>      
    </section>
  </body>
</html>