<?php include("../php/connection.php")?>
<?php session_start()?>
<!DOCTYPE html>
  <html lang="en">
  <?php include("../php/head.php")?>
  <body>
    <?php include("../php/global_patients.php")?>
  </body>
</html>