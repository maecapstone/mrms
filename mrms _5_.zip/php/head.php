<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Maternal Record Management System</title>
  <link rel="icon" href="../images/logo.svg">
  <link rel="stylesheet" href="../bootstrap-5.3.1-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <script type="text/javascript" src="../bootstrap-5.3.1-dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="../js/jquery-3.6.0.min.js" defer></script>
  <script type="text/javascript" src="../js/index.js" defer></script>

  <script type="text/javascript" src="../js/adapter.min.js"></script>
  <script type="text/javascript" src="../js/instascan.min.js"></script>
  <script type="text/javascript" src="../js/vue.min.js"></script>
  <script type="text/javascript" src="../js/jquery-3.6.0.min.js"></script>
</head>